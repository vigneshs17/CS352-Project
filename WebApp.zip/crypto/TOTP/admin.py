from django.contrib import admin

from .models import UserT

admin.site.register(UserT)
