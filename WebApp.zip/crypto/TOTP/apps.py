from django.apps import AppConfig


class TotpConfig(AppConfig):
    name = 'TOTP'
