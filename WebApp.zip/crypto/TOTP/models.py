from django.db import models
import hmac

# Create your models here.


class UserT(models.Model):
    userName = models.CharField(max_length=30)
    secretKey = models.CharField(max_length=8)

    def __str__(self):
        return self.userName

    def valid(self, otp: int):
        return self.secretKey == otp
