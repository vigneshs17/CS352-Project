from django.shortcuts import render
# Create your views here.
from .models import UserT
import random
import string
import pyqrcode
from . import help1


def index(request):
    return render(request, 'index.html')


def login(request):
    if request.method == "POST":
        user = request.POST['email']
        otp = request.POST['otp']
        q1 = UserT.objects.get(userName=user)
        if help1.validate_totp(otp, q1.secretKey) == 1:
            return render(request, 'success.html')
        print(help1.generate_totp(q1.secretKey))
    return render(request, 'login.html')


def register(request):
    if request.method == "POST":
        # print(request.POST['email'])
        User = UserT()
        User.userName = request.POST['email']

        def randStr(chars="QWERTYUIOPLKJHGFDSAZXCVBNM12345670", n=16):
            return ''.join(random.choice(chars) for _ in range(n))

        User.secretKey = randStr()
        User.save()
        s = "otpauth://totp/" + User.userName + "?secret=" + User.secretKey
        url = pyqrcode.create(s)
        print(url)
        url.svg("media/myqr.svg", scale=8)
        img = "../media/" + "myqr.svg"
        response = {'key': User.secretKey, 'img': img}
        return render(request, 'register2.html', response)
    return render(request, 'register.html')


